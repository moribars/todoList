package com.example.todolist.form;

public class TodoData {

}
